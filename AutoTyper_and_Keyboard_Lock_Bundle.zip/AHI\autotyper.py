#!/usr/bin/env python3
"""
Rock-Solid Auto-Typer using Python + pynput (Windows + Remote Keyboard Edition).
Reads the text dynamically from an external file (~/autotype_text.txt).
The file is re-read on every start.

Uses real Win32 Virtual Key codes (wVk) + Hardware Scan Codes (wScan) via
VkKeyScanW and MapVirtualKeyW so keystrokes transmit properly across remote
keyboard/desktop apps (AnyDesk, Parsec, GlideX, RDP, Bluetooth HID, KVM, etc.).
"""

import ctypes
from ctypes import wintypes
import os
import random
import signal
import subprocess
import sys
import threading
import time

from pynput import keyboard

# Default file location to read text from:
DEFAULT_FILE = os.path.expanduser("~/autotype_text.txt")

# Fallback text if the file doesn't exist:
FALLBACK_TEXT = """def hello():
    print("Hello, World!")

hello()"""

# Delay between characters in seconds (0.04 = fast, 0.06 = moderate, 0.10 = slow)
CHAR_DELAY = 0.001

# Countdown in seconds before typing starts
COUNTDOWN_SECONDS = 5

PID_FILE = os.path.expanduser("~/.autotyper.pid")

KEY_EQUALS = keyboard.KeyCode.from_char("=")
KEY_PLUS = keyboard.KeyCode.from_char("+")
KEY_MINUS = keyboard.KeyCode.from_char("-")
KEY_UNDERSCORE = keyboard.KeyCode.from_char("_")
KEY_Z = keyboard.KeyCode.from_char("z")
KEY_C = keyboard.KeyCode.from_char("c")
KEY_X = keyboard.KeyCode.from_char("x")

# Spaces per indent level (used when the file uses tabs)
TAB_WIDTH = 4
# After Enter, delete the IDE's auto-inserted indentation so the file's own
# leading whitespace is used instead. Set False if your editor misbehaves.
SMART_INDENT = True
# Slightly vary the delay between keys so typing looks less mechanical.
HUMAN_JITTER = True

# ---- Win32 SendInput Definitions --------------------------------------
user32 = ctypes.windll.user32
kernel32 = ctypes.windll.kernel32
winmm = ctypes.windll.winmm
ULONG_PTR = wintypes.WPARAM

try:
    winmm.timeBeginPeriod(1)
except Exception:
    pass

INPUT_KEYBOARD = 1
KEYEVENTF_EXTENDEDKEY = 0x0001
KEYEVENTF_KEYUP = 0x0002
KEYEVENTF_UNICODE = 0x0004
KEYEVENTF_SCANCODE = 0x0008

VK_TAB = 0x09
VK_RETURN = 0x0D
VK_SHIFT = 0x10
VK_CONTROL = 0x11
VK_MENU = 0x12
VK_CAPITAL = 0x14
VK_END = 0x23
VK_HOME = 0x24
VK_LWIN = 0x5B
VK_RWIN = 0x5C
VK_LSHIFT = 0xA0
VK_RSHIFT = 0xA1
VK_LCONTROL = 0xA2
VK_RCONTROL = 0xA3
VK_LMENU = 0xA4
VK_RMENU = 0xA5

EXTENDED_VKS = {VK_HOME, VK_END, VK_LWIN, VK_RWIN, VK_RCONTROL, VK_RMENU}
MODIFIER_VKS = (
    VK_SHIFT, VK_LSHIFT, VK_RSHIFT,
    VK_CONTROL, VK_LCONTROL, VK_RCONTROL,
    VK_MENU, VK_LMENU, VK_RMENU,
    VK_LWIN, VK_RWIN,
)


class MOUSEINPUT(ctypes.Structure):
    _fields_ = [
        ("dx", wintypes.LONG),
        ("dy", wintypes.LONG),
        ("mouseData", wintypes.DWORD),
        ("dwFlags", wintypes.DWORD),
        ("time", wintypes.DWORD),
        ("dwExtraInfo", ULONG_PTR),
    ]


class KEYBDINPUT(ctypes.Structure):
    _fields_ = [
        ("wVk", wintypes.WORD),
        ("wScan", wintypes.WORD),
        ("dwFlags", wintypes.DWORD),
        ("time", wintypes.DWORD),
        ("dwExtraInfo", ULONG_PTR),
    ]


class HARDWAREINPUT(ctypes.Structure):
    _fields_ = [
        ("uMsg", wintypes.DWORD),
        ("wParamL", wintypes.WORD),
        ("wParamH", wintypes.WORD),
    ]


class _INPUT_UNION(ctypes.Union):
    _fields_ = [
        ("mi", MOUSEINPUT),
        ("ki", KEYBDINPUT),
        ("hi", HARDWAREINPUT),
    ]


class INPUT(ctypes.Structure):
    _fields_ = [
        ("type", wintypes.DWORD),
        ("union", _INPUT_UNION),
    ]


def _make_vk_input(vk, key_up=False):
    scan = user32.MapVirtualKeyW(vk, 0)
    flags = KEYEVENTF_EXTENDEDKEY if vk in EXTENDED_VKS else 0
    if key_up:
        flags |= KEYEVENTF_KEYUP
    inp = INPUT()
    inp.type = INPUT_KEYBOARD
    inp.union.ki = KEYBDINPUT(wVk=vk, wScan=scan, dwFlags=flags, time=0, dwExtraInfo=0)
    return inp


def _make_unicode_input(code_unit, key_up=False):
    flags = KEYEVENTF_UNICODE | (KEYEVENTF_KEYUP if key_up else 0)
    inp = INPUT()
    inp.type = INPUT_KEYBOARD
    inp.union.ki = KEYBDINPUT(wVk=0, wScan=code_unit, dwFlags=flags, time=0, dwExtraInfo=0)
    return inp


def _send_inputs(inputs):
    if not inputs:
        return True
    arr = (INPUT * len(inputs))(*inputs)
    sent = user32.SendInput(len(inputs), arr, ctypes.sizeof(INPUT))
    return sent == len(inputs)


def _any_win32_modifier_down():
    for vk in MODIFIER_VKS:
        if user32.GetAsyncKeyState(vk) & 0x8000:
            return True
    return False


def _ensure_capslock_off():
    # If Caps Lock is toggled ON, turn it off so uppercase/lowercase letters
    # sent via hardware virtual keys + Shift are never inverted on remote machines.
    try:
        if user32.GetKeyState(VK_CAPITAL) & 0x0001:
            _send_inputs([_make_vk_input(VK_CAPITAL, False), _make_vk_input(VK_CAPITAL, True)])
            time.sleep(0.005)
    except Exception:
        pass


def cleanup_modifiers(d=None):
    try:
        ups = [_make_vk_input(vk, key_up=True) for vk in MODIFIER_VKS]
        _send_inputs(ups)
    except Exception:
        pass


def notify(msg):
    pass


class AutoTyper:
    def __init__(self, file_path=DEFAULT_FILE, delay=CHAR_DELAY):
        self.file_path = file_path
        self.delay = delay
        self.text = ""
        self.state = "STOPPED"  # STOPPED / COUNTDOWN / RUNNING / PAUSED
        self.index = 0
        self.gen = 0
        self._paused_from = None
        self._typing = False
        self.cond = threading.Condition()
        self.worker_thread = None
        self._xlock = threading.Lock()
        self._display = None
        self._charcache = {}

    def _rebuild_keymap(self):
        self._charcache.clear()

    # ---- text loading -------------------------------------------------
    def load_text(self):
        if os.path.exists(self.file_path):
            try:
                with open(self.file_path, "r", encoding="utf-8") as f:
                    content = f.read().replace("\r\n", "\n")
                if content.strip():
                    return content
                print(f"[AutoTyper] Warning: {self.file_path} is empty; using fallback text.")
            except Exception as e:
                print(f"[AutoTyper] Warning: Could not read {self.file_path}: {e}")
        else:
            print(f"[AutoTyper] Warning: {self.file_path} not found; using fallback text.")
        return FALLBACK_TEXT

    # ---- low-level Win32 VirtualKey + ScanCode SendInput --------------
    def _resolve(self, ch):
        if ch in self._charcache:
            return self._charcache[ch]
        if ch in ("\n", "\r"):
            res = (VK_RETURN, 0)
        elif ch == "\t":
            res = (VK_TAB, 0)
        else:
            try:
                raw = user32.VkKeyScanW(ch)
            except ctypes.ArgumentError:
                raw = user32.VkKeyScanW(ord(ch))
            vk_scan = ctypes.c_short(raw).value
            if vk_scan == -1:
                res = None
            else:
                vk = vk_scan & 0xFF
                shift_state = (vk_scan >> 8) & 0xFF
                res = (vk, shift_state)
        self._charcache[ch] = res
        return res

    def _tap_vk(self, vk):
        _send_inputs([_make_vk_input(vk, False), _make_vk_input(vk, True)])

    def _type_char(self, ch):
        resolved = self._resolve(ch)
        try:
            with self._xlock:
                if resolved is not None:
                    vk, shift_state = resolved
                    need_shift = bool(shift_state & 1)
                    need_ctrl = bool(shift_state & 2)
                    need_alt = bool(shift_state & 4)
                    events = []
                    if need_ctrl:
                        events.append(_make_vk_input(VK_LCONTROL, False))
                    if need_alt:
                        events.append(_make_vk_input(VK_LMENU, False))
                    if need_shift:
                        events.append(_make_vk_input(VK_LSHIFT, False))
                    events.append(_make_vk_input(vk, False))
                    events.append(_make_vk_input(vk, True))
                    if need_shift:
                        events.append(_make_vk_input(VK_LSHIFT, True))
                    if need_alt:
                        events.append(_make_vk_input(VK_LMENU, True))
                    if need_ctrl:
                        events.append(_make_vk_input(VK_LCONTROL, True))
                    return _send_inputs(events)

                # Fallback for non-keyboard Unicode symbols (emojis, etc.)
                utf16_bytes = ch.encode("utf-16-le")
                code_units = [
                    int.from_bytes(utf16_bytes[i : i + 2], "little")
                    for i in range(0, len(utf16_bytes), 2)
                ]
                events = []
                for cu in code_units:
                    events.append(_make_unicode_input(cu, key_up=False))
                    events.append(_make_unicode_input(cu, key_up=True))
                return _send_inputs(events)
        except Exception as e:
            print(f"[AutoTyper] Error typing {ch!r}: {e}")
            return False

    def _newline(self):
        with self._xlock:
            if not SMART_INDENT:
                self._tap_vk(VK_RETURN)
                return
            events = [
                _make_vk_input(VK_RETURN, False),
                _make_vk_input(VK_RETURN, True),
                _make_vk_input(VK_HOME, False),
                _make_vk_input(VK_HOME, True),
                _make_vk_input(VK_HOME, False),
                _make_vk_input(VK_HOME, True),
                _make_vk_input(VK_LSHIFT, False),
                _make_vk_input(VK_END, False),
                _make_vk_input(VK_END, True),
                _make_vk_input(VK_LSHIFT, True),
            ]
            _send_inputs(events)

    def _wait_for_modifiers_release(self):
        # Wait up to 1.5s for user to physically release start/resume hotkeys (Ctrl, Alt, Win, Shift)
        t_end = time.monotonic() + 1.5
        while time.monotonic() < t_end:
            if not (_has_ctrl() or _has_alt() or _has_cmd() or _any_win32_modifier_down()):
                break
            time.sleep(0.03)
        with self._xlock:
            cleanup_modifiers()
            _ensure_capslock_off()
        global _pressed
        _pressed.clear()
        time.sleep(0.05)

    def _worker(self, gen):
        # Countdown. Pauses freeze the remaining time; cancel bumps `gen`.
        remaining = float(COUNTDOWN_SECONDS)
        with self.cond:
            while remaining > 0:
                while self.state == "PAUSED":
                    self.cond.wait()
                if self.gen != gen or self.state != "COUNTDOWN":
                    return
                t0 = time.monotonic()
                self.cond.wait(timeout=min(0.1, remaining))
                remaining -= time.monotonic() - t0

            while self.state == "PAUSED":
                self.cond.wait()
            if self.gen != gen or self.state != "COUNTDOWN":
                return
            self._wait_for_modifiers_release()
            self.state = "RUNNING"
            total = len(self.text)

        print(f"[AutoTyper] Typing started ({total} characters)...")
        notify("Typing started")

        resumed_from_pause = False
        next_deadline = time.perf_counter()
        while True:
            with self.cond:
                while self.state == "PAUSED":
                    self.cond.wait()
                if self.gen != gen or self.state not in ("RUNNING", "RESUMING"):
                    return

                if self.state == "RESUMING":
                    # Grace period on resume so fingers leave Ctrl+Alt before typing
                    rem = 0.8
                    while rem > 0 and self.state == "RESUMING":
                        t0 = time.monotonic()
                        self.cond.wait(timeout=min(0.1, rem))
                        rem -= time.monotonic() - t0
                    if self.gen != gen or self.state != "RESUMING":
                        continue
                    self.state = "RUNNING"
                    resumed_from_pause = True

                if self.index >= len(self.text):
                    self.state = "STOPPED"
                    self.cond.notify_all()
                    done, ch, line_start = True, None, False
                else:
                    done, ch = False, self.text[self.index]
                    line_start = self.index == 0 or self.text[self.index - 1] == "\n"

            if done:
                print("[AutoTyper] Finished typing!")
                notify("Finished typing!")
                return

            if resumed_from_pause:
                self._wait_for_modifiers_release()
                resumed_from_pause = False
                next_deadline = time.perf_counter()

            self._typing = True
            try:
                if ch == "\n":
                    self._newline()
                    ok = True
                elif ch == "\t" and line_start:
                    # Typing Tab with a selection can indent the whole line in
                    # some IDEs; emit spaces instead.
                    ok = True
                    for _ in range(TAB_WIDTH):
                        ok = self._type_char(" ") and ok
                else:
                    ok = self._type_char(ch)
            finally:
                self._typing = False
            if not ok:
                print(f"[AutoTyper] Could not type {ch!r}; skipping.")

            with self.cond:
                # Only advance for the worker that still owns this session.
                if self.gen == gen and self.state in ("RUNNING", "PAUSED", "RESUMING"):
                    self.index += 1

            nap = self.delay
            if HUMAN_JITTER:
                nap *= random.uniform(0.6, 1.4)
            next_deadline += nap
            rem_wait = next_deadline - time.perf_counter()
            if rem_wait > 0.004:
                with self.cond:
                    if self.gen == gen and self.state == "RUNNING":
                        self.cond.wait(timeout=rem_wait - 0.002)
            while time.perf_counter() < next_deadline:
                if self.gen != gen or self.state != "RUNNING":
                    break

    # ---- controls -----------------------------------------------------
    def toggle(self):
        if self.state == "STOPPED":
            text = self.load_text()  # file IO outside the lock
            self._rebuild_keymap()
            with self.cond:
                if self.state != "STOPPED":
                    return
                self.text = text
                self.index = 0
                self.gen += 1
                self._paused_from = None
                self.state = "COUNTDOWN"
                self.worker_thread = threading.Thread(
                    target=self._worker, args=(self.gen,), daemon=True
                )
                self.worker_thread.start()
                self.cond.notify_all()
                chars, lines = len(self.text), len(self.text.splitlines())
            print(f"[AutoTyper] Loaded {chars} chars ({lines} lines) from {self.file_path}")
            print(f"[AutoTyper] Starting in {COUNTDOWN_SECONDS}s...")
            notify(f"Starting in {COUNTDOWN_SECONDS}s...")
            return

        with self.cond:
            if self.state in ("COUNTDOWN", "RUNNING", "RESUMING"):
                self._paused_from = self.state
                self.state = "PAUSED"
                self.cond.notify_all()
                action = "paused"
            elif self.state == "PAUSED":
                self.state = "RESUMING"
                self.cond.notify_all()
                action = "resumed"
            else:
                return

        if action == "paused":
            with self._xlock:
                cleanup_modifiers()
            global _pressed
            _pressed.clear()
            print("[AutoTyper] Paused.")
            notify("Paused (Ctrl+Alt+Space to resume, Esc to stop)")
        else:
            print("[AutoTyper] Resuming in 0.8s...")
            notify("Resuming in 0.8s...")

    def cancel(self):
        was_active = False
        with self.cond:
            if self.state != "STOPPED":
                was_active = True
                self.gen += 1  # invalidate any running worker
                self.state = "STOPPED"
                self.index = 0
                self.cond.notify_all()
        with self._xlock:
            cleanup_modifiers()
        global _pressed
        _pressed.clear()
        if was_active:
            notify("Stopped & Cancelled")
            print("[AutoTyper] Cancelled & Reset.")

    def adjust_delay(self, delta):
        with self.cond:
            self.delay = round(max(0.001, min(1.0, self.delay + delta)), 3)
            delay = self.delay
        cps = 1.0 / delay if delay > 0 else 0
        direction = "Slower" if delta > 0 else "Faster"
        msg = f"Delay: {delay:.2f}s (~{cps:.1f} chars/s) [{direction}]"
        print(f"[AutoTyper] {msg}")
        notify(msg)


# ---- global hotkeys ---------------------------------------------------
typer = None
_listener = None
_pressed = set()


def _norm(key):
    return _listener.canonical(key) if _listener else key


def _is_cmd(k):
    if k is None:
        return False
    k = _norm(k)
    return k in (keyboard.Key.cmd, keyboard.Key.cmd_l, keyboard.Key.cmd_r)


def _is_alt(k):
    if k is None:
        return False
    k = _norm(k)
    return k in (keyboard.Key.alt, keyboard.Key.alt_l, keyboard.Key.alt_r, keyboard.Key.alt_gr)


def _is_ctrl(k):
    if k is None:
        return False
    k = _norm(k)
    return k in (keyboard.Key.ctrl, keyboard.Key.ctrl_l, keyboard.Key.ctrl_r)


def _has_cmd():
    return any(_is_cmd(k) for k in _pressed)


def _has_alt():
    return any(_is_alt(k) for k in _pressed)


def _has_ctrl():
    return any(_is_ctrl(k) for k in _pressed)


def _is_key(k, chars, vks):
    if k is None:
        return False
    vk = getattr(k, "vk", None)
    ch = getattr(k, "char", None)
    if vk in vks or (ch and ch in chars):
        return True
    nk = _norm(k)
    return getattr(nk, "vk", None) in vks or getattr(nk, "char", None) in chars


def on_press(key, injected=False):
    if injected or key is None or (typer and typer._typing):
        return
    norm_key = _norm(key)
    if norm_key in _pressed:  # ignore auto-repeat
        return
    _pressed.add(norm_key)

    if norm_key == _norm(keyboard.Key.esc):
        if typer:
            typer.cancel()
        return

    # Primary Non-F Universal Shortcuts:
    # Ctrl + Alt + Space, Ctrl + Alt + Enter, or Ctrl + Alt + X / Z
    if _has_ctrl() and _has_alt():
        if norm_key in (_norm(keyboard.Key.space), _norm(keyboard.Key.enter)) or _is_key(
            key, ("x", "X", "\x18", "z", "Z", "\x1a"), (0x58, 0x5A)
        ):
            if typer:
                typer.toggle()
            return
        elif _is_key(key, ("c", "C", "\x03"), (0x43,)):
            if typer:
                typer.cancel()
            return

    # Secondary shortcut: Windows + Alt (in either press order)
    if (_is_alt(norm_key) and _has_cmd()) or (_is_cmd(norm_key) and _has_alt()):
        if typer:
            typer.toggle()
        return

    # Function key fallback: F8
    if norm_key == _norm(keyboard.Key.f8):
        if typer:
            typer.toggle()
        return

    if _is_key(key, ("=", "+"), (0xBB, 0x6B)):
        if _has_alt() and typer and not typer._typing:
            typer.adjust_delay(+0.02)
    elif _is_key(key, ("-", "_"), (0xBD, 0x6D)):
        if _has_alt() and typer and not typer._typing:
            typer.adjust_delay(-0.02)


def on_release(key, injected=False):
    if injected or key is None:
        return
    _pressed.discard(_norm(key))


# ---- PID helpers (Windows-compatible) ---------------------------------
def _read_pid():
    try:
        with open(PID_FILE) as f:
            return int(f.read().strip())
    except Exception:
        return None


def _pid_alive(pid):
    PROCESS_QUERY_LIMITED_INFORMATION = 0x1000
    STILL_ACTIVE = 259
    handle = kernel32.OpenProcess(PROCESS_QUERY_LIMITED_INFORMATION, False, int(pid))
    if not handle:
        return False
    try:
        exit_code = wintypes.DWORD()
        if kernel32.GetExitCodeProcess(handle, ctypes.byref(exit_code)):
            return exit_code.value == STILL_ACTIVE
        return True
    finally:
        kernel32.CloseHandle(handle)


def _is_autotyper(pid):
    try:
        res = subprocess.run(
            ["powershell", "-NoProfile", "-Command",
             f"(Get-CimInstance Win32_Process -Filter 'ProcessId = {int(pid)}').CommandLine"],
            capture_output=True,
            text=True,
            timeout=3,
        )
        return "autotyper" in (res.stdout or "").lower()
    except Exception:
        return True


def _remove_pid_file():
    try:
        if _read_pid() == os.getpid():
            os.remove(PID_FILE)
    except Exception:
        pass


def run_app(file_path):
    global typer, _listener
    typer = AutoTyper(file_path=file_path)

    print("=" * 60)
    print("AutoTyper Active & Listening (Windows + Remote Keyboard)")
    print("=" * 60)
    print(f"Reading from : {file_path}")
    print("Hotkeys:")
    print("  - Ctrl + Alt + Space : Toggle (Start / Pause / Resume) [Recommended]")
    print("  - Ctrl + Alt + Enter : Toggle Alternative")
    print("  - Ctrl + Alt + X / Z : Toggle Alternative")
    print("  - Win + Alt          : Toggle Alternative")
    print("  - F8                 : Toggle Alternative")
    print("  - Escape / Ctrl+Alt+C: Emergency Stop / Cancel (when active)")
    print("  - Alt + =            : Slower (increase delay)")
    print("  - Alt + -            : Faster (decrease delay)")
    print("=" * 60)
    print("Tip: Edit the text file anytime; it re-reads on every Start!")
    print("Press Ctrl+C in this terminal to exit.\n")

    _listener = keyboard.Listener(on_press=on_press, on_release=on_release)
    _listener.start()

    stop_event = threading.Event()

    def _handle_signal(signum, frame):
        stop_event.set()

    previous_term = signal.signal(signal.SIGTERM, _handle_signal)
    previous_int = signal.signal(signal.SIGINT, _handle_signal)

    try:
        while not stop_event.wait(0.5):
            pass
    finally:
        if typer:
            typer.cancel()
        _listener.stop()
        signal.signal(signal.SIGTERM, previous_term)
        signal.signal(signal.SIGINT, previous_int)


def main():
    target_file = DEFAULT_FILE

    if len(sys.argv) > 1:
        arg = sys.argv[1]
        if arg.lower() in ("stop", "kill", "cancel"):
            pid = _read_pid()
            if pid is None:
                print("AutoTyper is not running.")
                return
            if not _pid_alive(pid):
                print(f"AutoTyper is not running (stale PID {pid}).")
                try:
                    os.remove(PID_FILE)
                except Exception:
                    pass
                return
            try:
                os.kill(pid, signal.SIGTERM)
                print(f"Sent stop signal to AutoTyper (PID {pid}).")
            except Exception as e:
                print(f"Could not kill process: {e}")
            return
        elif arg == "--self-test":
            _self_test()
            return
        elif os.path.isfile(arg):
            target_file = os.path.abspath(arg)

    existing = _read_pid()
    if existing and existing != os.getpid() and _pid_alive(existing) and _is_autotyper(existing):
        print(f"AutoTyper is already running (PID {existing}). Use 'stop' first.")
        return

    with open(PID_FILE, "w") as f:
        f.write(str(os.getpid()))

    try:
        run_app(target_file)
    finally:
        _remove_pid_file()


def _self_test():
    import tempfile

    global COUNTDOWN_SECONDS, notify, cleanup_modifiers, _any_win32_modifier_down, _ensure_capslock_off
    COUNTDOWN_SECONDS = 0.2
    notify = lambda msg: None
    cleanup_modifiers = lambda d=None: None
    _any_win32_modifier_down = lambda: False
    _ensure_capslock_off = lambda: None

    with tempfile.NamedTemporaryFile("w", suffix=".txt", delete=False) as f:
        f.write("ab\nc")
        path = f.name

    try:
        typed = []
        t = AutoTyper(file_path=path)
        for sample_ch in ("a", "A", "1", "(", ")", "=", "+", "\n", "\t"):
            assert t._resolve(sample_ch) is not None, sample_ch
        t._type_char = lambda ch: (t._resolve(ch) is not None) and (typed.append(ch) or True)
        t._newline = lambda: typed.append("\n")

        t.toggle()
        t.worker_thread.join(timeout=5)
        assert typed == ["a", "b", "\n", "c"], typed
        assert t.state == "STOPPED", t.state

        typed.clear()
        t.toggle()
        time.sleep(0.05)
        t.cancel()
        t.worker_thread.join(timeout=5)
        assert typed == [], typed
        assert t.state == "STOPPED", t.state

        t.adjust_delay(+10.0)
        assert t.delay == 1.0, t.delay
        t.adjust_delay(-10.0)
        assert t.delay == 0.001, t.delay

        print("self-test: OK")
    finally:
        os.remove(path)


if __name__ == "__main__":
    main()
